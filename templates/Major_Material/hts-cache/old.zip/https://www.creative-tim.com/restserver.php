<!DOCTYPE html>
<html>

<head>
    <title>The page you were looking for doesn't exist (404)</title>

    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <link href="/static-pages-assets/style.css" rel="stylesheet" />
    <link href="/static-pages-assets/pe-icon-7-stroke.css" rel="stylesheet" />

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">

</head>

<body>

    <nav class="navbar navbar-default navbar-fixed-top navbar-transparent">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="/">
                    <div class="logo">
                        <img src="https://s3.amazonaws.com/creativetim_bucket/new_logo.png" width="60" height="60">
                    </div>
                    <p>Creative
                        <br> Tim</p>
                </a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="/">Home</a></li>
                    <li><a href="/about-us">About Us</a></li>
                    <li><a href="/contact-us">Contact Us</a></li>

                    <li>
                        <a href="https://www.facebook.com/CreativeTim/">
                            <i class="fa fa-facebook-square"></i>
                        </a>
                    </li>
                    <li>
                        <a href="https://www.instagram.com/creativetimofficial/">
                            <i class="fa fa-instagram"></i>
                        </a>
                    </li>
                    <li>
                        <a href="https://twitter.com/creativetim">
                            <i class="fa fa-twitter"></i>
                        </a>
                    </li>

                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>

    <div class="background" style="background-image: url('/static-pages-assets/background.jpeg'); background-position: center center; background-size: cover">
        <div class="container">
            <div class="text-center error-box">
                <br /><br /><br />
                <h1>404</h1>
                <h4>The page you requested could not be found.</h4>

                <div class="container-cards">
                    <h2>You can discover:</h2>
                    <div class="row">
                        <div class="col-md-3 col-sm-6">
                            <div class="card">
                                <a href="/bootstrap-themes/admin-dashboard">
                                    <div class="card-icon">
                                        <i class="pe-7s-display1"></i>
                                    </div>
                                    <div class="card-title">
                                        <h4>Admin & Dashboards</h>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6">
                            <div class="card">
                                <a href="/bootstrap-themes/ui-kit">
                                    <div class="card-icon">
                                        <i class="pe-7s-scissors"></i>
                                    </div>
                                    <div class="card-title">
                                        <h4>UI Kits</h>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6">
                            <div class="card">
                                <a href="/bootstrap-themes/free">
                                    <div class="card-icon">
                                        <i class="pe-7s-gift"></i>
                                    </div>
                                    <div class="card-title">
                                        <h4>Free Themes</h>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6">
                            <div class="card">
                                <a href="/bootstrap-themes/components">
                                    <div class="card-icon">
                                        <i class="pe-7s-plugin"></i>
                                    </div>
                                    <div class="card-title">
                                        <h4>Bootstrap Components</h>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>


    	    </div>
        </div>
    </div>

</body>
    <script   src="https://code.jquery.com/jquery-2.2.4.min.js"   integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44="   crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

</html>
